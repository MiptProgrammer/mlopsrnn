from code.train import train
from code.infer import infer


# train()

infer('Dusti')